from django.contrib import admin

from .models import EducationalBackground, FamilyBackground, Subjects, Course, StudentAccount

admin.site.register(EducationalBackground)
admin.site.register(FamilyBackground)
admin.site.register(Subjects)
admin.site.register(Course)
admin.site.register(StudentAccount)