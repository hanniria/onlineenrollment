from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import StudentAccount, EducationalBackground, FamilyBackground, Course, Subjects
from .forms import CourseForm, SubjectsForm, StudentAccountForm, EducationalBackgroundForm, FamilyBackgroundForm

# ------------------ COURSE VIEWS ------------------
@login_required
def course_list(request):
    courses = Course.objects.all()
    return render(request, 'online_enrollment/course_list.html', {'courses': courses})

@login_required
def add_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('course_list')
    else:
        form = CourseForm()
    return render(request, 'online_enrollment/add_course.html', {'form': form})

@login_required
def edit_course(request, pk):
    course = get_object_or_404(Course, pk=pk)
    if request.method == 'POST':
        form = CourseForm(request.POST, instance=course)
        if form.is_valid():
            form.save()
            return redirect('course_list')
    else:
        form = CourseForm(instance=course)
    return render(request, 'online_enrollment/edit_course.html', {'form': form})

# ------------------ SUBJECT VIEWS ------------------
@login_required
def subject_list(request):
    subjects = Subjects.objects.all()
    return render(request, 'online_enrollment/subject_list.html', {'subjects': subjects})

@login_required
def add_subject(request):
    if request.method == 'POST':
        form = SubjectsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('subject_list')
    else:
        form = SubjectsForm()
    return render(request, 'online_enrollment/add_subject.html', {'form': form})

@login_required
def edit_subject(request, pk):
    subject = get_object_or_404(Subjects, pk=pk)
    if request.method == 'POST':
        form = SubjectsForm(request.POST, instance=subject)
        if form.is_valid():
            form.save()
            return redirect('subject_list')
    else:
        form = SubjectsForm(instance=subject)
    return render(request, 'online_enrollment/edit_subject.html', {'form': form})

# ------------------ STUDENT ACCOUNT VIEWS ------------------
@login_required
def student_list(request):
    students = StudentAccount.objects.all()
    return render(request, 'online_enrollment/student_list.html', {'students': students})

@login_required
def add_student(request):
    if request.method == 'POST':
        form = StudentAccountForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentAccountForm()
    return render(request, 'online_enrollment/add_student.html', {'form': form})

@login_required
def edit_student(request, pk):
    student = get_object_or_404(StudentAccount, pk=pk)
    if request.method == 'POST':
        form = StudentAccountForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentAccountForm(instance=student)
    return render(request, 'online_enrollment/edit_student.html', {'form': form})

# ------------------ EDUCATION VIEWS ------------------
@login_required
def education_list(request):
    education_list = EducationalBackground.objects.all()
    return render(request, 'online_enrollment/education_list.html', {'education_list': education_list})

@login_required
def add_education(request):
    if request.method == 'POST':
        form = EducationalBackgroundForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('education_list')
    else:
        form = EducationalBackgroundForm()
    return render(request, 'online_enrollment/add_education.html', {'form': form})

@login_required
def edit_education(request, pk):
    edu = get_object_or_404(EducationalBackground, pk=pk)
    if request.method == 'POST':
        form = EducationalBackgroundForm(request.POST, instance=edu)
        if form.is_valid():
            form.save()
            return redirect('education_list')
    else:
        form = EducationalBackgroundForm(instance=edu)
    return render(request, 'online_enrollment/edit_education.html', {'form': form})

# ------------------ FAMILY BACKGROUND VIEWS ------------------
@login_required
def family_list(request):
    family_list = FamilyBackground.objects.all()
    return render(request, 'online_enrollment/family_list.html', {'family_list': family_list})

@login_required
def add_family(request):
    if request.method == 'POST':
        form = FamilyBackgroundForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('family_list')
    else:
        form = FamilyBackgroundForm()
    return render(request, 'online_enrollment/add_family.html', {'form': form})

@login_required
def edit_family(request, pk):
    fam = get_object_or_404(FamilyBackground, pk=pk)
    if request.method == 'POST':
        form = FamilyBackgroundForm(request.POST, instance=fam)
        if form.is_valid():
            form.save()
            return redirect('family_list')
    else:
        form = FamilyBackgroundForm(instance=fam)
    return render(request, 'online_enrollment/edit_family.html', {'form': form})

# ------------------ PROFILE & DASHBOARD ------------------
@login_required
def profile(request):
    user = request.user  
    return render(request, 'online_enrollment/profile.html', {'user': user})

@login_required
def dashboard(request):
    context = {
        'total_courses': Course.objects.count(),
        'total_subjects': Subjects.objects.count(),
        'total_students': StudentAccount.objects.count(),
        'students': StudentAccount.objects.all(),
        'education_list': EducationalBackground.objects.all(),
        'family_list': FamilyBackground.objects.all(),
        'courses': Course.objects.all(),
        'subjects': Subjects.objects.all(),
    }
    return render(request, 'online_enrollment/dashboard.html', context)

