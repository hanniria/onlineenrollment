from django import forms
from .models import Course, Subjects, StudentAccount, EducationalBackground, FamilyBackground

# ------------------ COURSE & SUBJECT FORMS ------------------
class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['course_name', 'course_description', 'instructor', 'program_head', 'major_subjects']

class SubjectsForm(forms.ModelForm):
    class Meta:
        model = Subjects
        fields = ['subject_name', 'time', 'code', 'units', 'grade']

# ------------------ STUDENT ACCOUNT FORM ------------------
class StudentAccountForm(forms.ModelForm):
    class Meta:
        model = StudentAccount
        fields = ['student_name', 'id_no', 'email', 'password', 'birthdate']
        widgets = {
            'password': forms.PasswordInput(),
            'birthdate': forms.DateInput(attrs={'type': 'date'})
        }

# ------------------ EDUCATIONAL BACKGROUND FORM ------------------
class EducationalBackgroundForm(forms.ModelForm):
    class Meta:
        model = EducationalBackground
        fields = ['preschool', 'primary_school', 'junior_high_school', 'senior_high_school', 'college']

# ------------------ FAMILY BACKGROUND FORM ------------------
class FamilyBackgroundForm(forms.ModelForm):
    class Meta:
        model = FamilyBackground
        fields = ['mother', 'father', 'contact', 'occupation', 'address']
        widgets = {
            'address': forms.Textarea(attrs={'rows': 2}),
        }
