from django.urls import path
from . import views

urlpatterns = [
    # Dashboard
    path('dashboard/', views.dashboard, name='dashboard'),

    # Profile
    path('profile/', views.profile, name='profile'),

    # ------------------ STUDENT ACCOUNT ------------------
    path('students/', views.student_list, name='student_list'),
    path('students/add/', views.add_student, name='add_student'),
    path('students/edit/<int:pk>/', views.edit_student, name='edit_student'),

    # ------------------ EDUCATIONAL BACKGROUND ------------------
    path('education/', views.education_list, name='education_list'),
    path('education/add/', views.add_education, name='add_education'),
    path('education/edit/<int:pk>/', views.edit_education, name='edit_education'),

    # ------------------ FAMILY BACKGROUND ------------------
    path('family/', views.family_list, name='family_list'),
    path('family/add/', views.add_family, name='add_family'),
    path('family/edit/<int:pk>/', views.edit_family, name='edit_family'),

    # ------------------ COURSES ------------------
    path('courses/', views.course_list, name='course_list'),
    path('courses/add/', views.add_course, name='add_course'),
    path('courses/edit/<int:pk>/', views.edit_course, name='edit_course'),

    # ------------------ SUBJECTS ------------------
    path('subjects/', views.subject_list, name='subject_list'),
    path('subjects/add/', views.add_subject, name='add_subject'),
    path('subjects/edit/<int:pk>/', views.edit_subject, name='edit_subject'),
]
