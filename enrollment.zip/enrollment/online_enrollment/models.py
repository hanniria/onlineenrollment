from django.db import models

class StudentAccount(models.Model):
    student_name = models.CharField(max_length=50)
    id_no = models.PositiveIntegerField(unique=True)
    email = models.EmailField(max_length=100, unique=True)
    password = models.CharField(max_length=100) 
    birthdate = models.DateField()

    def __str__(self):
        return f"{self.student_name} (ID: {self.id_no}) "


class EducationalBackground(models.Model):
    preschool = models.CharField(max_length=50)
    primary_school = models.CharField(max_length=50)
    junior_high_school = models.CharField(max_length=50)
    senior_high_school = models.CharField(max_length=50)
    college = models.CharField(max_length=50)

    def __str__(self):
        return f"College: {self.college}"


class FamilyBackground(models.Model):
    mother = models.CharField(max_length=50)
    father = models.CharField(max_length=50)
    contact = models.CharField(max_length=15) 
    occupation = models.CharField(max_length=50)
    address = models.CharField(max_length=200)

    def __str__(self):
        return f"Mother: {self.mother}"


class Course(models.Model):
    course_name = models.CharField(max_length=100)
    course_description = models.CharField(max_length=100)
    instructor = models.CharField(max_length=100)
    program_head = models.CharField(max_length=100)
    major_subjects = models.CharField(max_length=100)

    def __str__(self):
        return self.course_name


class Subjects(models.Model):
    subject_name = models.CharField(max_length=100)
    time = models.CharField(max_length=100)
    code = models.CharField(max_length=100)
    units = models.IntegerField()
    grade = models.DecimalField(max_digits=5, decimal_places=2)

    def __str__(self):
        return f"{self.subject_name} ({self.code})"
